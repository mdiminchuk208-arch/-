# Crypto Bot — Phase 1.4.14 v0.4.14

## Cross-Asset Robustness Validation

Phase 1.4.14 supersedes v0.4.13 as the current QA/infrastructure layer. It does **not** change the source definitions of Swing, HH/HL, LL/LH, BOS, CONF, structural SFP, Range-boundary SFP or MTF SFP->BOS.

### Frozen production policy

- Structure analysis: `SOURCE_CONSERVATIVE`.
- `TECHNICAL_RECOVERY`: diagnostic/counterfactual only.
- Global cross-pair clustering: exact timestamp only (`0` minutes).
- `trade_entry_allowed=false` everywhere.

### Cross-asset QA basket

Default required basket:

`BTCUSDT ETHUSDT SOLUSDT XRPUSDT BNBUSDT DOGEUSDT ADAUSDT LINKUSDT AVAXUSDT LTCUSDT`

Required timeframes:

`5 15 60 240`

The basket is a project QA policy, not a source trading rule.

### Why Phase 1.4.14 exists

The packaged 240-day evidence before this phase covers BTCUSDT and ETHUSDT only. Phase 1.4.14 adds a reproducible cross-asset harness so a broader market basket can be checked before Entry Engine work.

Pass/fail is based only on data/causality/provenance/runtime/safety invariants. Event counts are diagnostic only; no profitability threshold is inferred.

### Fetch the full basket

In an environment with internet access to the public Bybit V5 API:

```bash
PYTHONPATH=src python scripts/fetch_bybit_mtf_history.py \
  --symbols BTCUSDT ETHUSDT SOLUSDT XRPUSDT BNBUSDT DOGEUSDT ADAUSDT LINKUSDT AVAXUSDT LTCUSDT \
  --intervals 5 15 60 240 \
  --days 240
```

### Run the production cross-asset audit

```bash
PYTHONPATH=src python scripts/analyze_cross_asset_robustness.py \
  --symbols BTCUSDT ETHUSDT SOLUSDT XRPUSDT BNBUSDT DOGEUSDT ADAUSDT LINKUSDT AVAXUSDT LTCUSDT \
  --evaluation-days 240 \
  --suffix-days 60 \
  --stabilization-days 7 \
  --analysis-warmup-days 0
```

`--analysis-warmup-days` is QA context only, not a trading parameter. For a full 240-day package that starts at the evaluation boundary, `0` is the honest setting; shorter smoke runs may load extra pre-evaluation context when available.

Outputs default to:

`data/reports/phase1_4_14/cross_asset_240d/`

The summary records input hashes, code hashes, per-symbol checks and the explicit gate decision.

### Packaged smoke evidence

The archive includes only BTCUSDT/ETHUSDT histories, so the full ten-symbol gate cannot be closed here. A short real-data smoke run for both packaged symbols is retained under:

`data/reports/phase1_4_14/smoke_btc_eth_30d/`

Both packaged symbols pass the per-symbol invariants; the overall gate remains open because eight required symbols are missing.

### Remaining Entry Engine blockers

- `RANGE_DETECTION_NORMALIZATION_NOT_VALIDATED`
- `RANGE_BOUNDARY_CLARITY_THRESHOLD_NOT_FORMALIZED`
- `RANGE_EXIT_REENTRY_LIFECYCLE_NOT_FORMALIZED`
- `CROSS_ASSET_ROBUSTNESS_NOT_VALIDATED`
- `ENTRY_ZONE_SL_TARGET_RR_NOT_IMPLEMENTED`

### Tests

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
python -B -m compileall -q src scripts tests
```

Current target: **198 tests PASS**.

### Safety boundary

This phase creates no trade entry, private exchange connection or order. Entry Zone / SL / FTA / TP / RR remain later work.
