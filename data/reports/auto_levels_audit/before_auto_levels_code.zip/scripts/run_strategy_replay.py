"""Run offline BACKTEST/SHADOW observation and optional virtual management on CSV history."""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import asdict
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path

from crypto_bot.data.storage import read_klines_csv
from crypto_bot.strategy.replay import EngineMode, QualifiedLevels, STRATEGY_VERSION, evaluate_snapshot
from crypto_bot.strategy.virtual_portfolio import VirtualPortfolio


def encode(value):
    if isinstance(value, datetime):
        return value.isoformat()
    raise TypeError(f"unsupported report value: {type(value).__name__}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root', type=Path, default=Path('data/history/bybit'))
    parser.add_argument('--report-root', type=Path, default=Path('data/reports/strategy_replay'))
    parser.add_argument('--symbols', nargs='+', default=['BTCUSDT'])
    parser.add_argument('--htf', type=int, default=60)
    parser.add_argument('--ltf', type=int, default=5)
    parser.add_argument('--bars', type=int, default=288)
    parser.add_argument('--warmup-bars', type=int, default=576)
    parser.add_argument('--mode', choices=[m.value for m in EngineMode], default='BACKTEST')
    parser.add_argument('--qualified-levels', type=Path,
                        help='JSON signal_id -> known_at/stop_loss/targets/stop_policy/target_policy; no automatic qualification')
    args = parser.parse_args()
    if args.bars <= 0 or args.warmup_bars < 0 or not 0 < args.ltf < args.htf:
        parser.error('positive bars, nonnegative warmup and 0 < LTF < HTF required')
    symbols = [s.strip().upper() for s in args.symbols]
    if not all(symbols) or len(set(symbols)) != len(symbols):
        parser.error('symbols must be nonempty and unique')
    qualified = {}
    if args.qualified_levels:
        payload = json.loads(args.qualified_levels.read_text(encoding='utf-8'))
        for key, row in payload.items():
            qualified[key] = QualifiedLevels(datetime.fromisoformat(row['known_at']), row['stop_loss'],
                                              tuple(row['targets']), row['stop_policy'], row['target_policy'])
    data, hashes = {}, {}
    for symbol in symbols:
        data[symbol] = {}
        for tf in (args.ltf, args.htf):
            path = args.data_root / symbol / f'{tf}.csv'
            rows = read_klines_csv(path)
            if not rows or any(r.exchange != 'BYBIT' or r.symbol != symbol or r.interval != str(tf) for r in rows):
                raise ValueError(f'missing/incorrect CSV series identity: {path}')
            data[symbol][tf] = [r.to_strategy_candle(tf * 60000) for r in rows]
            hashes[f'{symbol}/{tf}.csv'] = sha256(path.read_bytes()).hexdigest()
    end = min(cs[-1].close_time for series in data.values() for cs in series.values())
    execution = {}
    for symbol in symbols:
        cs = [c for c in data[symbol][args.ltf] if c.close_time <= end]
        if len(cs) < args.bars:
            raise ValueError(f'insufficient execution bars: {symbol}')
        execution[symbol] = cs[-args.bars:]
        start = cs[max(0, len(cs) - args.bars - args.warmup_bars)].open_time
        data[symbol] = {tf: [c for c in series if c.open_time >= start and c.close_time <= end]
                        for tf, series in data[symbol].items()}
    portfolio = VirtualPortfolio(mode=args.mode)
    updates, states, snapshot_counts = [], {}, Counter()
    for i in range(args.bars):
        bars = {symbol: execution[symbol][i] for symbol in sorted(symbols)}
        as_of = next(iter(bars.values())).close_time
        signals = []
        for symbol in sorted(symbols):
            snapshot = evaluate_snapshot(data[symbol], symbol=symbol, as_of=as_of,
                                         htf_minutes=args.htf, ltf_minutes=args.ltf,
                                         mode=args.mode, qualified_levels=qualified)
            snapshot_counts[symbol] += 1
            signals.extend(snapshot.signals)
            for signal in snapshot.signals:
                row = asdict(signal)
                row['direction'] = signal.direction.name
                signature = {k: v for k, v in row.items() if k != 'event_time'}
                canonical = json.dumps(signature, sort_keys=True, default=encode)
                if states.get(signal.signal_id) != canonical:
                    updates.append(row)
                    states[signal.signal_id] = canonical
        portfolio.step(bars, signals)
    args.report_root.mkdir(parents=True, exist_ok=True)
    payload = {
        'strategy_version': STRATEGY_VERSION, 'mode': args.mode,
        'analysis_mode': 'SOURCE_CONSERVATIVE', 'trade_entry_allowed': False,
        'symbols': sorted(symbols), 'htf_minutes': args.htf, 'ltf_minutes': args.ltf,
        'bars_per_symbol': args.bars, 'warmup_bars': args.warmup_bars,
        'input_hashes': hashes, 'policy': asdict(portfolio.policy),
        'qualified_level_inputs': {key: asdict(value) for key, value in qualified.items()},
        'snapshots_per_symbol': dict(snapshot_counts), 'signal_updates': updates,
        'unique_signal_count': len(states),
        'decision_count': len(portfolio.journal),
        'virtual_entry_count': sum(d.action == 'VIRTUAL_ENTRY' for d in portfolio.journal),
        'final_equity': portfolio.equity, 'open_virtual_positions': sorted(portfolio.positions),
        'pending_virtual_setups': len(portfolio.pending),
        'limitations': ['SL_AND_THREE_TARGETS_REQUIRE_CALLER_SOURCE_QUALIFICATION',
                        'SCORE_AND_MIDPOINT_ENTRY_ARE_BACKTEST_PARAMETERS',
                        'CLOSED_HTF_OBSERVATION_CAN_DELAY_NEXT_OPEN_SFP',
                        'FUNDING_AND_LIQUIDATION_NOT_MODELLED', 'NO_LIVE_FEED_OR_EXECUTION_ADAPTER'],
    }
    summary = json.dumps(payload, indent=2, sort_keys=True, default=encode) + '\n'
    journal = ''.join(json.dumps(asdict(d), sort_keys=True, default=encode) + '\n' for d in portfolio.journal)
    (args.report_root / 'summary.json').write_text(summary, encoding='utf-8')
    (args.report_root / 'decisions.jsonl').write_text(journal, encoding='utf-8')
    digest = sha256((summary + journal).encode('utf-8')).hexdigest()
    (args.report_root / 'fingerprint.sha256').write_text(digest + '\n', encoding='utf-8')
    print(f'{args.mode}: {len(symbols)} symbols, {args.bars} bars each; {len(states)} unique setups; '
          f'{payload["virtual_entry_count"]} virtual entries; trade_entry_allowed=false; fingerprint={digest}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
