# Crypto Bot / Strategy Engine

Core version: **0.4.20**. Offline replay policy: **0.4.20-replay.1**.
The directory/archive name retains `phase1_4_18` for compatibility.

The current project analyzes market structure, structural/range SFPs, causal
HTF→LTF BOS links and source-qualified OTE geometry. It also provides offline
BACKTEST/SHADOW observation and virtual position management.

`trade_entry_allowed=false`. LIVE and PAPER modes are rejected by the replay
interface. No private exchange client, real order adapter or production-site
integration is added.

## Architecture

- `data/`: public Bybit history, CSV storage and coverage/data QA.
- `strategy/market_analysis.py`, `structure.py`, `sfp.py`: causal closed-candle
  market structure, liquidity episodes and SFP formation/invalidation.
- `strategy/range_engine.py`: range creation, midpoint validation, consumed
  boundaries, retirement and range SFPs. Clarity review defaults to UNREVIEWED;
  only explicit review PASS qualifies a range SFP.
- `strategy/mtf_sfp.py`, `global_opportunity.py`: strictly post-SFP BOS linking,
  invalidation precedence, provenance and opportunity deduplication.
- `strategy/trade_plan.py`, `order_block.py`: OTE and qualified reference
  geometry. Automatic OB/POI qualification remains an explicit blocker.
- `strategy/replay.py`: immutable as-of snapshots and explained signals.
- `strategy/virtual_portfolio.py`: simulated next-open entries, risk guards,
  TP1/TP2/TP3 (40/30/30) and fee/slippage-adjusted breakeven.
- `scripts/run_strategy_replay.py`: reproducible offline CSV replay, input
  hashes, JSON signal updates, JSONL decisions and output fingerprint.

See [STRATEGY_REPLAY.md](STRATEGY_REPLAY.md) for contracts and limitations, and
[STRATEGY_ENGINE_WORK_REPORT.md](STRATEGY_ENGINE_WORK_REPORT.md) for measured
baseline, corrections and verification evidence.

## Tests

Run from this project directory; no third-party runtime dependencies are needed:

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
python -B -m compileall -q src scripts tests
```

## Offline replay

```bash
PYTHONPATH=src python scripts/run_strategy_replay.py \
  --symbols BTCUSDT ETHUSDT --bars 48 --warmup-bars 576 \
  --report-root data/reports/strategy_replay
```

Add `--mode SHADOW` for the same read-only observation and virtual management
policy. The CLI consumes packaged history; it does not connect a current-market
feed. Without caller-qualified stop and three targets, entry stays blocked.

## Preserved policies

Structure uses SOURCE_CONSERVATIVE; recovery remains diagnostic. Production
cross-pair clustering uses exact timestamps. Core source geometry and its risk
skeleton remain distinct from explicit replay experiment parameters.

The virtual portfolio follows the requested 2–5% per-trade risk, at most 6%
aggregate modeled stop risk, configurable daily loss limit, Isolated leverage
up to x5 (default x3), and re-entry score at least 75 after trade completion.
The daily limit stays latched until the next UTC risk day; existing positions
continue to be managed.

Historical PHASE documents describe earlier stages. Their claims are not a
substitute for current logs and reports under `data/reports/work_audit/`.
