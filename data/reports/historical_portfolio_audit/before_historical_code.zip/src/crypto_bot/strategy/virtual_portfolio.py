"""Deterministic isolated-margin simulation; no exchange or order integration.

Entry is at a later candle OPEN inside the entry zone. Closed OHLC bars have
unknown intrabar order: an old stop wins ties, then TP1/BE wins over higher TPs.
Fees and slippage apply to every partial exit. Funding/liquidation are not modelled.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from math import isfinite
from typing import Mapping, Sequence

from crypto_bot.common.models import Candle, Direction
from crypto_bot.strategy.market_analysis import StructureAnalysisMode
from crypto_bot.strategy.replay import EngineMode, StrategySignal


@dataclass(frozen=True)
class SimulationPolicy:
    risk_fraction: float = 0.02
    max_total_risk: float = 0.06
    daily_loss_limit: float = 0.04
    leverage: float = 3.0
    margin_mode: str = "Isolated"
    fee_fraction: float = 0.0006
    slippage_fraction: float = 0.0002
    reentry_min_score: int = 75

    def __post_init__(self):
        values = (self.risk_fraction, self.max_total_risk, self.daily_loss_limit,
                  self.leverage, self.fee_fraction, self.slippage_fraction)
        if not all(isfinite(v) for v in values):
            raise ValueError("simulation policy values must be finite")
        if not 0.02 <= self.risk_fraction <= 0.05 or not 0 < self.max_total_risk <= 0.06:
            raise ValueError("risk must be 2%-5%; portfolio cap must be at most 6%")
        if self.risk_fraction > self.max_total_risk or not 0 < self.daily_loss_limit < 1:
            raise ValueError("invalid risk or daily loss budget")
        if not 1 <= self.leverage <= 5 or self.margin_mode != "Isolated":
            raise ValueError("only Isolated leverage in [1, 5] is supported")
        if not 0 <= self.fee_fraction < 0.1 or not 0 <= self.slippage_fraction < 0.1:
            raise ValueError("invalid fees/slippage")
        if not isinstance(self.reentry_min_score, int) or not 75 <= self.reentry_min_score <= 100:
            raise ValueError("reentry score must be at least 75")


@dataclass(frozen=True)
class Decision:
    sequence: int
    time: datetime
    symbol: str
    signal_id: str
    action: str
    reason: str
    quantity: float = 0.0
    price: float | None = None
    net_pnl: float = 0.0
    trade_entry_allowed: bool = field(default=False, init=False)


@dataclass
class VirtualPosition:
    signal: StrategySignal
    entry_time: datetime
    entry_price: float
    quantity: float
    remaining_fraction: float
    stop_loss: float
    tp_stage: int = 0


class VirtualPortfolio:
    """Use the same state machine in BACKTEST and SHADOW; admissions are virtual.

    Supply all execution-symbol bars for each timestamp in one batch to avoid
    using one symbol's candle-close PnL for another symbol's same-open risk guard.
    Risk day is UTC, daily limit is latched until the next UTC day. Re-entry is
    only on a new signal after completion, with score >=75.
    """
    def __init__(self, *, equity: float = 10000.0, policy: SimulationPolicy | None = None,
                 mode: EngineMode | str = EngineMode.BACKTEST):
        if not isfinite(equity) or equity <= 0:
            raise ValueError("equity must be finite and positive")
        self.mode, self.policy, self.equity = EngineMode(mode), policy or SimulationPolicy(), equity
        self.positions: dict[str, VirtualPosition] = {}
        self.pending: dict[str, StrategySignal] = {}
        self.completed_symbols: set[str] = set()
        self.consumed_ids: set[str] = set()
        self.terminal_ids: set[str] = set()
        self._journal: list[Decision] = []
        self._last_close: datetime | None = None
        self._bar_duration = None
        self._day = None
        self._day_start_equity = equity
        self._daily_blocked = False

    @property
    def trade_entry_allowed(self):
        return False

    @property
    def journal(self):
        return tuple(self._journal)

    def _log(self, when, signal, action, reason, quantity=0.0, price=None, pnl=0.0):
        self._journal.append(Decision(len(self._journal) + 1, when, signal.symbol,
                                      signal.signal_id, action, reason, quantity, price, pnl))

    def _exit_price(self, reference, direction):
        sign = 1 if direction == Direction.LONG else -1
        return reference * (1 - sign * self.policy.slippage_fraction)

    def _loss_per_unit(self, entry, stop, direction):
        sign = 1 if direction == Direction.LONG else -1
        exit_price = self._exit_price(stop, direction)
        return max(0.0, sign * (entry - exit_price) + self.policy.fee_fraction * (entry + exit_price))

    def _breakeven(self, position):
        f, s, entry = self.policy.fee_fraction, self.policy.slippage_fraction, position.entry_price
        if position.signal.direction == Direction.LONG:
            return entry * (1 + f) / ((1 - f) * (1 - s))
        return entry * (1 - f) / ((1 + f) * (1 + s))

    def _close_fraction(self, position, fraction, reference, when, reason):
        self._roll_day(when)
        quantity = position.quantity * fraction
        exit_price = self._exit_price(reference, position.signal.direction)
        sign = 1 if position.signal.direction == Direction.LONG else -1
        pnl = quantity * (sign * (exit_price - position.entry_price)
                          - self.policy.fee_fraction * (position.entry_price + exit_price))
        self.equity += pnl
        position.remaining_fraction = max(0.0, position.remaining_fraction - fraction)
        self._log(when, position.signal, "VIRTUAL_EXIT", reason, quantity, exit_price, pnl)
        if self.equity <= self._day_start_equity * (1 - self.policy.daily_loss_limit):
            self._daily_blocked = True
        if position.remaining_fraction < 1e-12:
            self.positions.pop(position.signal.symbol)
            self.completed_symbols.add(position.signal.symbol)

    def _manage(self, position, candle):
        long = position.signal.direction == Direction.LONG
        stop_hit = candle.low <= position.stop_loss if long else candle.high >= position.stop_loss
        if stop_hit:
            reference = min(position.stop_loss, candle.open) if long else max(position.stop_loss, candle.open)
            self._close_fraction(position, position.remaining_fraction, reference, candle.close_time, "STOP_FIRST_CONSERVATIVE")
            return
        for stage, fraction in enumerate((0.4, 0.3, 0.3)):
            if stage < position.tp_stage:
                continue
            target = position.signal.targets[stage]
            hit = candle.high >= target if long else candle.low <= target
            if not hit:
                break
            self._close_fraction(position, fraction, target, candle.close_time, f"TP{stage + 1}")
            position.tp_stage = stage + 1
            if stage == 0:
                position.stop_loss = self._breakeven(position)
                self._log(candle.close_time, position.signal, "VIRTUAL_STOP_UPDATE", "BREAKEVEN_WITH_FEES_AND_SLIPPAGE", price=position.stop_loss)
                be_hit = candle.low <= position.stop_loss if long else candle.high >= position.stop_loss
                if be_hit:
                    self._close_fraction(position, position.remaining_fraction, position.stop_loss,
                                         candle.close_time, "BREAKEVEN_SAME_BAR_CONSERVATIVE")
                    return

    def _roll_day(self, when):
        day = when.astimezone(timezone.utc).date()
        if day != self._day:
            self._day, self._day_start_equity, self._daily_blocked = day, self.equity, False

    def _admit(self, signal, candle):
        reason = None
        if signal.symbol in self.positions:
            reason = "PREVIOUS_POSITION_STILL_OPEN"
        elif self._daily_blocked:
            reason = "DAILY_LOSS_LIMIT_LATCHED"
        elif signal.symbol in self.completed_symbols and signal.score < self.policy.reentry_min_score:
            reason = "REENTRY_SCORE_BELOW_75"
        elif self.equity <= 0:
            reason = "EQUITY_EXHAUSTED"
        if reason:
            self._log(candle.open_time, signal, "VIRTUAL_ENTRY_BLOCKED", reason)
            self.consumed_ids.add(signal.signal_id)
            return True
        if not signal.entry_zone.low <= candle.open <= signal.entry_zone.high:
            return False
        sign = 1 if signal.direction == Direction.LONG else -1
        entry = candle.open * (1 + sign * self.policy.slippage_fraction)
        # Costs must not shift the fill across the stop or first target.
        if not (sign * (entry - signal.stop_loss) > 0 and sign * (signal.targets[0] - entry) > 0):
            self._log(candle.open_time, signal, "VIRTUAL_ENTRY_BLOCKED", "COST_ADJUSTED_FILL_GEOMETRY")
            self.consumed_ids.add(signal.signal_id)
            return True
        target_exit = self._exit_price(signal.targets[0], signal.direction)
        first_target_net = sign * (target_exit - entry) - self.policy.fee_fraction * (entry + target_exit)
        if first_target_net <= 0:
            # Otherwise the calculated BE stop lies beyond TP1 and could be
            # falsely filled at a price outside the bar after TP1 is hit.
            self._log(candle.open_time, signal, "VIRTUAL_ENTRY_BLOCKED", "TP1_NOT_POSITIVE_AFTER_COSTS")
            self.consumed_ids.add(signal.signal_id)
            return True
        risk = self.equity * self.policy.risk_fraction
        quantity = risk / self._loss_per_unit(entry, signal.stop_loss, signal.direction)
        existing_risk = sum(p.quantity * p.remaining_fraction * self._loss_per_unit(p.entry_price, p.stop_loss, p.signal.direction)
                            for p in self.positions.values())
        margin = sum(p.quantity * p.remaining_fraction * p.entry_price / self.policy.leverage for p in self.positions.values())
        if existing_risk + risk > self.equity * self.policy.max_total_risk + 1e-9:
            reason = "TOTAL_RISK_CAP_6_PERCENT"
        elif margin + quantity * entry / self.policy.leverage > self.equity:
            reason = "ISOLATED_MARGIN_BUDGET"
        if reason:
            self._log(candle.open_time, signal, "VIRTUAL_ENTRY_BLOCKED", reason)
        else:
            self.positions[signal.symbol] = VirtualPosition(signal, candle.open_time, entry, quantity, 1.0, signal.stop_loss)
            self._log(candle.open_time, signal, "VIRTUAL_ENTRY", "NEXT_OPEN_INSIDE_ENTRY_ZONE", quantity, entry)
        self.consumed_ids.add(signal.signal_id)
        return True

    @staticmethod
    def _validate_signal(signal, close_time, bars, mode):
        if signal.event_time.utcoffset() is None or signal.sfp_time.utcoffset() is None or signal.bos_time.utcoffset() is None:
            raise ValueError("signal timestamps must be timezone-aware")
        if not signal.sfp_time < signal.bos_time <= signal.event_time or signal.event_time != close_time:
            raise ValueError("signals must be causal and submitted at their observation close")
        if signal.symbol not in bars or signal.ltf_minutes != int((bars[signal.symbol].close_time - bars[signal.symbol].open_time).total_seconds() / 60):
            raise ValueError("signal symbol/timeframe must match execution bar")
        if EngineMode(signal.mode) != mode or signal.analysis_mode != StructureAnalysisMode.SOURCE_CONSERVATIVE or signal.trade_entry_allowed:
            raise ValueError("only safe source-conservative signals in the portfolio mode are accepted")
        if signal.direction not in (Direction.LONG, Direction.SHORT) or not isinstance(signal.score, int) or not 0 <= signal.score <= 100:
            raise ValueError("invalid signal direction/score")
        for timestamp in (signal.entry_geometry_ready_time, signal.levels_known_at):
            if timestamp is not None and (timestamp.utcoffset() is None or timestamp > signal.event_time):
                raise ValueError("entry references cannot be available in the future")
        if signal.status == "READY_FOR_VIRTUAL_ENTRY":
            if signal.entry_zone is None or signal.stop_loss is None or len(signal.targets) != 3:
                raise ValueError("ready signal requires entry zone, SL and three targets")
            if signal.entry_geometry_ready_time is None or signal.levels_known_at is None:
                raise ValueError("ready signal requires geometry and level availability timestamps")
            if signal.entry_geometry_ready_time < signal.bos_time:
                raise ValueError("entry geometry cannot precede BOS")
            prices = (signal.stop_loss, *signal.targets)
            if not all(isfinite(v) and v > 0 for v in prices):
                raise ValueError("ready prices must be finite and positive")
            sign = 1 if signal.direction == Direction.LONG else -1
            values = tuple(sign * v for v in (signal.stop_loss, signal.entry_zone.low if sign == 1 else signal.entry_zone.high,
                                             signal.entry_zone.high if sign == 1 else signal.entry_zone.low, *signal.targets))
            if not values[0] < values[1] <= values[2] < values[3] < values[4] < values[5]:
                raise ValueError("ready signal stop/entry/target geometry is invalid")

    def step(self, bars: Mapping[str, Candle], signals: Sequence[StrategySignal] = ()):
        if not bars:
            raise ValueError("execution batch cannot be empty")
        first = next(iter(bars.values()))
        for candle in bars.values():
            if not candle.is_closed or candle.low <= 0 or (candle.open_time, candle.close_time) != (first.open_time, first.close_time):
                raise ValueError("batch must contain closed positive-price bars of the same interval")
        if self._last_close is not None and first.open_time != self._last_close:
            raise ValueError("execution batches must be contiguous and cannot be replayed")
        duration = first.close_time - first.open_time
        if self._bar_duration is not None and duration != self._bar_duration:
            raise ValueError("execution timeframe cannot change within a replay")
        if set(self.positions) - set(bars):
            raise ValueError("every open position requires a bar in each batch")
        for signal in signals:
            self._validate_signal(signal, first.close_time, bars, self.mode)
        self._roll_day(first.open_time)
        # All entries use only PnL known before this batch's OPEN.
        for key, signal in sorted(tuple(self.pending.items()), key=lambda item: (item[1].symbol, item[0])):
            if signal.symbol in bars and self._admit(signal, bars[signal.symbol]):
                self.pending.pop(key)
        for symbol in sorted(tuple(self.positions)):
            self._manage(self.positions[symbol], bars[symbol])
        for signal in signals:
            if signal.status in ("INVALIDATED", "REJECTED_ENTRY_GEOMETRY", "SOURCE_CONTEXT_BLOCKED"):
                self.terminal_ids.add(signal.signal_id)
                self.pending.pop(signal.signal_id, None)
                action = "SETUP_INVALIDATED" if signal.status == "INVALIDATED" else "SETUP_REJECTED"
                self._log(first.close_time, signal, action,
                          '|'.join(signal.invalidation_reasons) or '|'.join(signal.reasons))
            elif signal.signal_id in self.terminal_ids or signal.signal_id in self.consumed_ids:
                continue
            elif signal.status == "READY_FOR_VIRTUAL_ENTRY":
                self.pending[signal.signal_id] = signal
                self._log(first.close_time, signal, "SETUP_READY", '|'.join(signal.reasons))
            else:
                # A formerly ready setup can lose its automatic POI evidence.
                # Withdraw it at this close before another next-open admission.
                self.pending.pop(signal.signal_id, None)
                reason = '|'.join((signal.status, *signal.level_blocking_reasons))
                self._log(first.close_time, signal, "SETUP_WAITING", reason)
        self._last_close = first.close_time
        self._bar_duration = duration
        return self.journal
